const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const idr=n=>"Rp "+Number(n).toLocaleString("id-ID");
const STATUS={menunggu_pembayaran:"Menunggu Pembayaran",pembayaran_berhasil:"Pembayaran Berhasil",sedang_diproses:"Sedang Diproses",berhasil:"Berhasil",gagal:"Gagal",dibatalkan:"Dibatalkan"};
async function api(path,opt={}){
  const o={credentials:"same-origin",headers:{"X-Requested-With":"nexora"},...opt};
  if(opt.body){o.headers["Content-Type"]="application/json";o.body=JSON.stringify(opt.body);o.method=opt.method||"POST"}
  const r=await fetch("/api"+path,o);let d={};try{d=await r.json()}catch{}
  if(!r.ok)throw Object.assign(new Error((d.details&&d.details.join("; "))||d.error||"Terjadi kesalahan."),{status:r.status});
  return d}
