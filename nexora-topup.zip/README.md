# NEXORA TOP UP

## Struktur
- frontend/index.html — halaman utama (statis, data contoh)
- database/schema.sql — skema PostgreSQL + data awal contoh
- backend/ — API Express (auth, katalog, pesanan, webhook, admin)

## Menjalankan lokal
1. createdb nexora && psql -d nexora -f database/schema.sql
2. cd backend && cp .env.example .env  (isi DATABASE_URL, SESSION_SECRET, WEBHOOK_SECRET)
3. npm install && npm start   (API di http://localhost:4000)
4. Admin lokal: ADMIN_EMAIL=... ADMIN_PASSWORD='min-12-karakter' npm run seed:admin

## Endpoint
GET /api/games, /api/games/:slug, /api/banners, /api/articles
POST /api/auth/register|login|logout, GET /api/auth/me, /api/auth/orders
POST /api/orders  (harga dihitung server) · GET /api/orders/:no?token=...
POST /api/orders/:no/sandbox-pay  (SIMULASI, hanya mode sandbox)
POST /webhook/payment  (header X-Signature = HMAC-SHA256 body)
GET /api/admin/stats|orders · POST/PATCH/DELETE /api/admin/products  (role admin)
Semua POST/PATCH/DELETE wajib header X-Requested-With: nexora.

## Status
Belum diuji dengan database nyata. Pembayaran dan pengiriman diamond masih SIMULASI sandbox;
belum ada integrasi Midtrans/Xendit/distributor. Voucher, lupa password, dan frontend checkout belum dibuat.

## Frontend terhubung
Backend menyajikan folder frontend/ (satu origin, tanpa CORS). Setelah `npm start`, buka http://localhost:4000
- / katalog dari API · /topup.html?g=slug (checkout) · /order.html (status + simulasi bayar)
- /auth.html (login, daftar, riwayat) · /admin.html (dashboard, perlu role admin)
Catatan: CSP mengizinkan inline script agar tetap sederhana; pindahkan ke file .js sebelum produksi.
Belum ada: CRUD admin lewat UI (game/banner/artikel/harga), voucher, lupa password, Midtrans/Xendit.

## Midtrans Sandbox
1. Daftar di dashboard.sandbox.midtrans.com, ambil Server Key (Settings > Access Keys).
2. Di backend/.env: PAYMENT_GATEWAY=midtrans, MIDTRANS_SERVER_KEY=..., MIDTRANS_ENV=sandbox.
3. Settings > Configuration > Payment Notification URL: https://DOMAIN-PUBLIK/webhook/midtrans
   (lokal: pakai tunnel seperti ngrok/cloudflared).
4. Buat pesanan, klik "Bayar Sekarang", bayar dengan simulator Midtrans. Status berubah lewat webhook bertanda tangan.
Mode production: ganti key dan MIDTRANS_ENV=production setelah akun disetujui dan SEMUA alur diuji.
Belum diuji dengan akun Midtrans nyata. Disarankan menambah pengecekan status ke API Midtrans sebelum menandai lunas.
Admin: /admin.html kini bisa tambah, ubah harga, aktif/nonaktif, dan hapus produk.

## Distributor (Digiflazz)
1. Daftar Digiflazz, ambil username + API key (mulai dengan DEV key dan DIGIFLAZZ_TESTING=true).
2. Isi PROVIDER=digiflazz dan DIGIFLAZZ_* di .env. Atur Webhook URL: https://DOMAIN/webhook/digiflazz (secret = DIGIFLAZZ_WEBHOOK_SECRET).
3. Kolom products.sku HARUS sama dengan buyer_sku_code Digiflazz. customer_no dikirim sebagai UserID+ZoneID tanpa spasi;
   cek format tiap game di dokumentasi Digiflazz karena bisa berbeda.
4. Hasil "Pending" tetap Sedang Diproses sampai callback; jika jaringan putus, admin bisa klik "Cek ulang" di dashboard (ref_id sama, tidak terkirim ganda).
Belum diuji dengan akun Digiflazz nyata.

## Fitur lain
Admin /admin-content.html: kelola kategori, game, banner, artikel, voucher, testimoni (moderasi), dan pengaturan WhatsApp/kontak.
Voucher dipakai di checkout (kuota & masa berlaku divalidasi server). Lupa password via email (tanpa SMTP: tautan dicetak ke log server, hanya untuk dev).
Pesanan lewat batas bayar dibatalkan otomatis tiap 5 menit. Halaman privasi/syarat hanya DRAF.
Perbaikan penting: ditambah express-async-errors (tanpanya error async di Express 4 membuat request menggantung).

## Deploy 1-klik (Render Blueprint)
Push repo ke GitHub, di Render pilih New > Blueprint, pilih repo. Isi ADMIN_EMAIL, ADMIN_PASSWORD (min. 12 karakter), APP_URL (alamat https Render).
Skema database dan akun admin dibuat otomatis saat server pertama jalan. Awalnya mode SANDBOX (tanpa uang nyata).
## Go-live (uang nyata) — wajib semua
1. Midtrans akun production (verifikasi bisnis) + MIDTRANS_ENV=production, PAYMENT_GATEWAY=midtrans, MIDTRANS_SERVER_KEY.
2. Digiflazz: PROVIDER=digiflazz, DIGIFLAZZ_*, saldo deposit cukup, webhook diatur.
3. Ganti SEMUA sku & harga produk contoh dengan data resmi distributor (Admin > Kelola Produk).
4. Uji dulu dengan Midtrans Sandbox + DIGIFLAZZ_TESTING=true. Server menolak start jika Midtrans production dipakai tanpa Digiflazz.
