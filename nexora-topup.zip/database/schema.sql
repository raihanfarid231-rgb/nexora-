-- NEXORA TOP UP — PostgreSQL schema (v1)
-- Jalankan: psql -U postgres -d nexora -f nexora_schema.sql
-- Harga = NUMERIC(12,2) dalam IDR. Tidak ada data kartu pembayaran yang disimpan.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- Pemicu updated_at
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$ LANGUAGE plpgsql;

-- ENUM
CREATE TYPE order_status   AS ENUM ('menunggu_pembayaran','pembayaran_berhasil','sedang_diproses','berhasil','gagal','dibatalkan');
CREATE TYPE payment_status AS ENUM ('pending','paid','failed','expired','refunded');
CREATE TYPE discount_type  AS ENUM ('percent','fixed');

-- ========== USERS & ROLES ==========
CREATE TABLE roles (
  id SMALLSERIAL PRIMARY KEY,
  name VARCHAR(30) NOT NULL UNIQUE,          -- customer, admin, superadmin
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  role_id SMALLINT NOT NULL REFERENCES roles(id),
  username VARCHAR(40) NOT NULL UNIQUE,
  email CITEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,               -- argon2id / bcrypt, TIDAK pernah plaintext
  phone VARCHAR(20),
  is_active BOOLEAN NOT NULL DEFAULT true,
  email_verified_at TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_role ON users(role_id);

CREATE TABLE password_resets (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,                  -- simpan hash token, bukan token asli
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pwreset_user ON password_resets(user_id);

-- ========== GAMES & PRODUCTS ==========
CREATE TABLE game_categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE,
  slug VARCHAR(60) NOT NULL UNIQUE,
  sort_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE games (
  id BIGSERIAL PRIMARY KEY,
  category_id INT NOT NULL REFERENCES game_categories(id),
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  publisher VARCHAR(100),
  image_url TEXT,                             -- placeholder sampai ada aset legal
  currency_name VARCHAR(30) DEFAULT 'Diamonds',
  requires_zone_id BOOLEAN NOT NULL DEFAULT false,
  id_help_text TEXT,                          -- petunjuk menemukan User ID
  label VARCHAR(10) CHECK (label IN ('HOT','POPULER')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_games_category ON games(category_id);
CREATE INDEX idx_games_active_sort ON games(is_active, sort_order);

CREATE TABLE products (                       -- nominal diamond + harga
  id BIGSERIAL PRIMARY KEY,
  game_id BIGINT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,                 -- "86 Diamonds"
  description TEXT,
  sku VARCHAR(60) NOT NULL UNIQUE,            -- kode di distributor
  cost_price  NUMERIC(12,2) NOT NULL CHECK (cost_price >= 0),   -- harga modal
  price       NUMERIC(12,2) NOT NULL CHECK (price >= 0),        -- harga jual
  promo_price NUMERIC(12,2) CHECK (promo_price >= 0),
  promo_label VARCHAR(30),
  promo_ends_at TIMESTAMPTZ,
  is_available BOOLEAN NOT NULL DEFAULT true, -- status ketersediaan
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_products_game ON products(game_id, is_available);

-- ========== VOUCHERS ==========
CREATE TABLE vouchers (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  type discount_type NOT NULL,
  value NUMERIC(12,2) NOT NULL CHECK (value > 0),
  max_discount NUMERIC(12,2),
  min_order NUMERIC(12,2) NOT NULL DEFAULT 0,
  quota INT,                                  -- NULL = tanpa batas
  used_count INT NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ========== ORDERS ==========
CREATE TABLE orders (
  id BIGSERIAL PRIMARY KEY,
  order_no VARCHAR(30) NOT NULL UNIQUE,       -- mis. NX20261014-7F3K9Q
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,  -- NULL = tamu
  voucher_id BIGINT REFERENCES vouchers(id),
  contact_email CITEXT,
  contact_whatsapp VARCHAR(20),
  subtotal NUMERIC(12,2) NOT NULL CHECK (subtotal >= 0),
  fee      NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (fee >= 0),
  discount NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  total    NUMERIC(12,2) NOT NULL CHECK (total >= 0),      -- dihitung server
  status order_status NOT NULL DEFAULT 'menunggu_pembayaran',
  lookup_token_hash TEXT,                     -- verifikasi tambahan cek pesanan
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (contact_email IS NOT NULL OR contact_whatsapp IS NOT NULL)
);
CREATE INDEX idx_orders_user ON orders(user_id, created_at DESC);
CREATE INDEX idx_orders_status ON orders(status, created_at DESC);

CREATE TABLE order_items (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL REFERENCES products(id),
  game_id BIGINT NOT NULL REFERENCES games(id),
  account_id VARCHAR(50) NOT NULL,            -- User ID game pelanggan
  zone_id VARCHAR(20),
  account_username VARCHAR(80),
  product_name VARCHAR(100) NOT NULL,         -- snapshot saat checkout
  unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),  -- snapshot harga
  quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
  fulfillment_status order_status NOT NULL DEFAULT 'menunggu_pembayaran',
  provider_ref VARCHAR(100),                  -- ID transaksi distributor
  fulfilled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_items_order ON order_items(order_id);
CREATE INDEX idx_items_product ON order_items(product_id);

-- ========== PAYMENTS ==========
CREATE TABLE payments (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  gateway VARCHAR(20) NOT NULL,               -- midtrans / xendit / sandbox
  method VARCHAR(30) NOT NULL,                -- qris, bca_va, gopay, ...
  gateway_ref VARCHAR(100) UNIQUE,
  amount NUMERIC(12,2) NOT NULL CHECK (amount >= 0),
  status payment_status NOT NULL DEFAULT 'pending',
  pay_url TEXT,
  paid_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_order ON payments(order_id);

CREATE TABLE payment_events (                 -- log webhook, juga untuk idempotency
  id BIGSERIAL PRIMARY KEY,
  payment_id BIGINT REFERENCES payments(id) ON DELETE SET NULL,
  gateway VARCHAR(20) NOT NULL,
  event_id VARCHAR(120) NOT NULL,             -- ID unik dari gateway
  event_type VARCHAR(50),
  signature_valid BOOLEAN NOT NULL,
  payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (gateway, event_id)                  -- webhook ganda tidak diproses 2x
);
CREATE INDEX idx_pevents_payment ON payment_events(payment_id);

CREATE TABLE transaction_logs (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,
  actor_user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(60) NOT NULL,                -- status_changed, provider_called, ...
  from_status order_status,
  to_status order_status,
  detail JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_txlogs_order ON transaction_logs(order_id, created_at);

-- ========== KONTEN ==========
CREATE TABLE banners (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  subtitle VARCHAR(200),
  image_url TEXT,
  link_url TEXT,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,                        -- masa berlaku promo
  sort_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE articles (
  id BIGSERIAL PRIMARY KEY,
  author_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  title VARCHAR(160) NOT NULL,
  slug VARCHAR(160) NOT NULL UNIQUE,
  excerpt TEXT,
  body TEXT NOT NULL,
  image_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT false,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_articles_pub ON articles(is_published, published_at DESC);

CREATE TABLE testimonials (                   -- hanya dari pelanggan nyata
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT UNIQUE REFERENCES orders(id) ON DELETE SET NULL,
  display_name VARCHAR(60) NOT NULL,
  content TEXT NOT NULL,
  is_approved BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE settings (
  key VARCHAR(60) PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- updated_at triggers
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['users','game_categories','games','products','vouchers','orders','order_items','payments','banners','articles','settings'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%1$s_upd BEFORE UPDATE ON %1$s FOR EACH ROW EXECUTE FUNCTION set_updated_at()', t);
  END LOOP;
END $$;

-- ========== DATA AWAL (CONTOH) ==========
INSERT INTO roles(name) VALUES ('customer'),('admin'),('superadmin');

INSERT INTO game_categories(name,slug,sort_order) VALUES
 ('Mobile Legends','mobile-legends',1),('Free Fire','free-fire',2),('Free Fire MAX','free-fire-max',3),
 ('PUBG Mobile','pubg-mobile',4),('Honor of Kings','honor-of-kings',5),('Genshin Impact','genshin-impact',6),
 ('Valorant','valorant',7),('Call of Duty Mobile','call-of-duty-mobile',8),('Roblox','roblox',9);

INSERT INTO games(category_id,name,slug,publisher,requires_zone_id,id_help_text,label,sort_order)
SELECT c.id,c.name,c.slug,p.pub,p.zone,p.help,p.lbl,c.sort_order
FROM game_categories c JOIN (VALUES
 ('mobile-legends','Moonton',true,'Ketuk avatar di pojok kiri atas untuk melihat User ID dan Zone ID.','HOT'),
 ('free-fire','Garena',false,'Ketuk avatar untuk melihat ID karakter.','HOT'),
 ('free-fire-max','Garena',false,'Ketuk avatar untuk melihat ID karakter.',NULL),
 ('pubg-mobile','Tencent Games',false,'Buka profil untuk melihat Character ID.',NULL),
 ('honor-of-kings','Tencent Games',false,'Buka profil untuk melihat Player ID.',NULL),
 ('genshin-impact','HoYoverse',true,'UID ada di pojok kanan bawah layar menu; pilih server yang sesuai.',NULL),
 ('valorant','Riot Games',false,'Gunakan Riot ID (Nama#Tag).',NULL),
 ('call-of-duty-mobile','Activision',false,'Buka profil untuk melihat UID.',NULL),
 ('roblox','Roblox Corp.',false,'Gunakan username Roblox.',NULL)
) AS p(slug,pub,zone,help,lbl) ON p.slug=c.slug;

INSERT INTO game_categories(name,slug,sort_order) VALUES ('Game Lainnya','game-lainnya',10);
INSERT INTO games(category_id,name,slug,publisher,requires_zone_id,id_help_text,label,sort_order)
SELECT (SELECT id FROM game_categories WHERE slug='game-lainnya'),v.n,v.s,v.pub,false,v.help,NULL,v.o FROM (VALUES
 ('Magic Chess','magic-chess','Moonton','Buka profil untuk melihat User ID.',10),
 ('Undawn','undawn','Level Infinite','Buka profil untuk melihat ID pemain.',11),
 ('Arena Breakout','arena-breakout','Level Infinite','Buka profil untuk melihat ID pemain.',12)) AS v(n,s,pub,help,o);
UPDATE games SET image_url='/img/'||slug||'.jpg';

-- Nominal Rp1.000–550.000 untuk semua game. JUMLAH & HARGA = CONTOH; SKU = PLACEHOLDER.
-- WAJIB sebelum jualan nyata: ganti sku dengan buyer_sku_code distributor dan harga dengan
-- harga resmi + margin kamu (Admin > Kelola Produk).
INSERT INTO products(game_id,name,sku,cost_price,price,sort_order)
SELECT g.id,
  floor(l.p / CASE WHEN g.slug='mobile-legends' THEN 256 ELSE 250 END)::int || ' ' ||
  CASE g.slug WHEN 'genshin-impact' THEN 'Genesis Crystals' WHEN 'valorant' THEN 'VP' WHEN 'roblox' THEN 'Robux'
    WHEN 'call-of-duty-mobile' THEN 'CP' WHEN 'pubg-mobile' THEN 'UC' WHEN 'honor-of-kings' THEN 'Tokens' ELSE 'Diamonds' END,
  upper(g.slug) || '-' || l.p, round(l.p * 0.97), l.p, l.p
FROM games g CROSS JOIN unnest(ARRAY[1000,5000,10000,15000,20000,25000,30000,50000,75000,100000,150000,200000,250000,300000,400000,500000,550000]) AS l(p);

INSERT INTO settings(key,value) VALUES
 ('site_name','NEXORA TOP UP'),('whatsapp_number',''),('whatsapp_enabled','false'),
 ('payment_mode','sandbox'),('order_expiry_minutes','60');

-- Akun admin demo (LOKAL SAJA): buat lewat skrip seed backend yang meng-hash password,
-- lalu GANTI sebelum deploy. Jangan menaruh hash/password di file SQL.

COMMIT;
