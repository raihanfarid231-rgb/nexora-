// CSRF: cookie sameSite=lax + wajib header kustom pada request yang mengubah data
export function csrfGuard(req, res, next) {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !req.path.startsWith('/webhook')) {
    if (req.get('X-Requested-With') !== 'nexora') return res.status(403).json({ error: 'Permintaan ditolak.' });
  }
  next();
}
export const requireAuth = (req, res, next) =>
  req.session.user ? next() : res.status(401).json({ error: 'Silakan login.' });
// Role dicek di server dari session, bukan dari klien
export const requireRole = (...roles) => (req, res, next) =>
  req.session.user && roles.includes(req.session.user.role) ? next() : res.status(403).json({ error: 'Akses ditolak.' });
export const validate = (schema, src = 'body') => (req, res, next) => {
  const r = schema.safeParse(req[src]);
  if (!r.success) return res.status(400).json({ error: 'Data tidak valid.', details: r.error.issues.map(i => `${i.path.join('.')}: ${i.message}`) });
  req[src] = r.data; next();
};
