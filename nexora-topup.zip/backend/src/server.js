import 'dotenv/config';
import 'express-async-errors';   // Express 4 tidak menangkap error async tanpa ini
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import session from 'express-session';
import connectPg from 'connect-pg-simple';
import rateLimit from 'express-rate-limit';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { pool, tx } from './db.js';
import { csrfGuard } from './middleware.js';
import catalog from './routes/catalog.js';
import auth from './routes/auth.js';
import orders from './routes/orders.js';
import webhook from './routes/webhook.js';
import admin from './routes/admin.js';

for (const k of ['DATABASE_URL', 'SESSION_SECRET', 'WEBHOOK_SECRET']) if (!process.env[k]) { console.error(`Env ${k} belum diisi.`); process.exit(1); }
// PENGAMAN: jangan pernah menerima uang nyata dengan pengiriman simulasi
if (process.env.PAYMENT_GATEWAY === 'midtrans' && process.env.MIDTRANS_ENV === 'production' && process.env.PROVIDER !== 'digiflazz') {
  console.error('DIHENTIKAN: Midtrans production butuh PROVIDER=digiflazz (pengiriman sandbox tidak mengirim item sungguhan).'); process.exit(1);
}
// Buat skema otomatis saat pertama jalan & buat admin dari env (tanpa psql/shell)
if (!(await pool.query("SELECT to_regclass('public.roles') AS t")).rows[0].t) {
  await pool.query(fs.readFileSync(new URL('../../database/schema.sql', import.meta.url), 'utf8')); console.log('Skema database dibuat.');
}
if (process.env.ADMIN_EMAIL && (process.env.ADMIN_PASSWORD || '').length >= 12) {
  await pool.query(`INSERT INTO users(role_id,username,email,password_hash) VALUES ((SELECT id FROM roles WHERE name='superadmin'),'admin',$1,$2) ON CONFLICT (email) DO NOTHING`,
    [process.env.ADMIN_EMAIL, await bcrypt.hash(process.env.ADMIN_PASSWORD, 12)]);
}
const app = express();
const prod = process.env.NODE_ENV === 'production';
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:', 'https:']
} } }));
app.use(cors({ origin: process.env.FRONTEND_URL || false, credentials: true }));

// Webhook butuh body mentah untuk verifikasi signature — daftar sebelum express.json()
app.use('/webhook', express.raw({ type: '*/*', limit: '100kb' }), webhook);

app.use(express.json({ limit: '50kb' }));
app.use(session({
  store: new (connectPg(session))({ pool, createTableIfMissing: true }),
  name: 'nx.sid', secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, secure: prod, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120 }));
app.use(csrfGuard);

app.use('/api', catalog);
app.use('/api/auth', auth);
app.use('/api/orders', orders);
app.use('/api/admin', admin);

app.use(express.static(new URL('../../frontend', import.meta.url).pathname));
app.use((req, res) => res.status(404).json({ error: 'Tidak ditemukan.' }));
app.use((err, req, res, next) => {
  const s = err.status && err.status < 500 ? err.status : 500;
  if (s === 500) console.error(err);
  res.status(s).json({ error: s < 500 ? err.message : 'Terjadi kesalahan server.' });
});

// Batalkan pesanan yang lewat batas waktu bayar & kembalikan kuota voucher
setInterval(async () => {
  try {
    await tx(async c => {
      const r = await c.query(`UPDATE orders SET status='dibatalkan' WHERE status='menunggu_pembayaran' AND expires_at<now() RETURNING id,voucher_id`);
      for (const o of r.rows) {
        if (o.voucher_id) await c.query('UPDATE vouchers SET used_count=GREATEST(used_count-1,0) WHERE id=$1', [o.voucher_id]);
        await c.query(`UPDATE payments SET status='expired' WHERE order_id=$1 AND status='pending'`, [o.id]);
        await c.query(`INSERT INTO transaction_logs(order_id,action,from_status,to_status) VALUES ($1,'order_expired','menunggu_pembayaran','dibatalkan')`, [o.id]);
      }
    });
  } catch (e) { console.error('expiry job', e); }
}, 5 * 60_000).unref();
app.listen(process.env.PORT || 4000, () => console.log(`NEXORA API jalan. Mode pembayaran: ${process.env.PAYMENT_GATEWAY || 'sandbox'}`));
