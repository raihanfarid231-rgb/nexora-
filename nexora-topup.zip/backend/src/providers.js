// Adapter distributor top up. PROVIDER=sandbox (simulasi) atau digiflazz.
import crypto from 'crypto';
import { q, tx } from './db.js';
import { send } from './mailer.js';

// Setiap adapter mengembalikan { status: 'berhasil'|'gagal'|'sedang_diproses', ref }
const adapters = {
  async sandbox(item) { return { status: 'berhasil', ref: 'SANDBOX-' + item.id };   // SIMULASI, tidak mengirim diamond
  },
  async digiflazz(item) {
    const u = process.env.DIGIFLAZZ_USERNAME, k = process.env.DIGIFLAZZ_API_KEY;
    const ref = `${item.order_no}-${item.id}`;                      // ref_id unik; kirim ulang ref sama = idempoten
    const body = { username: u, buyer_sku_code: item.sku, customer_no: item.account_id + (item.zone_id || ''), ref_id: ref,
      sign: crypto.createHash('md5').update(u + k + ref).digest('hex') };
    if (process.env.DIGIFLAZZ_TESTING === 'true') body.testing = true;
    try {
      const r = await fetch('https://api.digiflazz.com/v1/transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = (await r.json()).data || {};
      return { status: d.status === 'Sukses' ? 'berhasil' : d.status === 'Gagal' ? 'gagal' : 'sedang_diproses', ref: d.sn || ref };
    } catch { return { status: 'sedang_diproses', ref };           // hasil tidak diketahui: JANGAN tandai gagal
    }
  }
};

export async function fulfillOrder(orderId) {
  const adapter = adapters[process.env.PROVIDER || 'sandbox'];
  const go = await tx(async c => {
    const o = (await c.query('SELECT status FROM orders WHERE id=$1 FOR UPDATE', [orderId])).rows[0];
    if (!o) return false;
    if (o.status === 'pembayaran_berhasil') {
      await c.query(`UPDATE orders SET status='sedang_diproses' WHERE id=$1`, [orderId]);
      await c.query(`INSERT INTO transaction_logs(order_id,action,from_status,to_status) VALUES ($1,'fulfillment_started','pembayaran_berhasil','sedang_diproses')`, [orderId]);
      return true;
    }
    return o.status === 'sedang_diproses';                          // boleh dicoba ulang (admin)
  });
  if (!go) return;
  const items = (await q(`SELECT oi.*, o.order_no, p.sku FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN products p ON p.id=oi.product_id
                          WHERE oi.order_id=$1 AND oi.fulfillment_status IN ('menunggu_pembayaran','sedang_diproses')`, [orderId])).rows;
  for (const it of items) {
    const r = await adapter(it);
    await q(`UPDATE order_items SET fulfillment_status=$2, provider_ref=$3, fulfilled_at=CASE WHEN $2::order_status='berhasil' THEN now() END WHERE id=$1`, [it.id, r.status, r.ref]);
  }
  await finalizeOrder(orderId);
}

export async function finalizeOrder(orderId) {
  const items = (await q('SELECT fulfillment_status AS s FROM order_items WHERE order_id=$1', [orderId])).rows;
  if (items.some(i => !['berhasil', 'gagal'].includes(i.s))) return;   // masih menunggu callback distributor
  const to = items.every(i => i.s === 'berhasil') ? 'berhasil' : 'gagal';
  const up = await q(`UPDATE orders SET status=$2 WHERE id=$1 AND status='sedang_diproses' RETURNING order_no,contact_email`, [orderId, to]);
  if (!up.rowCount) return;
  await q(`INSERT INTO transaction_logs(order_id,action,from_status,to_status) VALUES ($1,'fulfillment_done','sedang_diproses',$2)`, [orderId, to]);
  const o = up.rows[0];
  await send(o.contact_email, `Pesanan ${o.order_no}: ${to === 'berhasil' ? 'Berhasil' : 'Gagal diproses'}`,
    to === 'berhasil' ? `Pesanan ${o.order_no} berhasil diproses.` : `Pesanan ${o.order_no} gagal diproses. Tim kami akan menghubungi Anda untuk pengembalian dana.`);
}

// Dipanggil webhook distributor
export async function applyProviderResult(ref, providerStatus, sn) {
  const status = providerStatus === 'Sukses' ? 'berhasil' : providerStatus === 'Gagal' ? 'gagal' : null;
  const i = ref.lastIndexOf('-'); if (!status || i < 1) return;
  const r = await q(`UPDATE order_items oi SET fulfillment_status=$3::order_status, provider_ref=COALESCE($4,provider_ref),
      fulfilled_at=CASE WHEN $3::order_status='berhasil' THEN now() END
      FROM orders o WHERE oi.order_id=o.id AND o.order_no=$1 AND oi.id=$2 AND oi.fulfillment_status='sedang_diproses' RETURNING o.id`,
    [ref.slice(0, i), ref.slice(i + 1), status, sn || null]);
  if (r.rowCount) await finalizeOrder(r.rows[0].id);
}
