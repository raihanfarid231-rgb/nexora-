import crypto from 'crypto';
import { tx } from './db.js';

export const sign = (raw) => crypto.createHmac('sha256', process.env.WEBHOOK_SECRET).update(raw).digest('hex');
export function verifySignature(raw, sig) {
  if (!sig) return false;
  const a = Buffer.from(sign(raw)), b = Buffer.from(String(sig));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Satu-satunya jalur yang boleh mengubah status pembayaran. Idempoten.
export async function processPaymentEvent({ gateway, eventId, gatewayRef, status, amount, payload, signatureValid }) {
  return tx(async c => {
    const ins = await c.query(
      `INSERT INTO payment_events(gateway,event_id,event_type,signature_valid,payload) VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT (gateway,event_id) DO NOTHING RETURNING id`, [gateway, eventId, status, signatureValid, payload]);
    if (!ins.rowCount) return { result: 'duplicate' };          // sudah pernah diproses
    if (!signatureValid) return { result: 'invalid_signature' };

    const p = (await c.query(`SELECT * FROM payments WHERE gateway_ref=$1 FOR UPDATE`, [gatewayRef])).rows[0];
    if (!p) return { result: 'unknown_payment' };
    await c.query('UPDATE payment_events SET payment_id=$1, processed_at=now() WHERE id=$2', [p.id, ins.rows[0].id]);
    if (p.status !== 'pending') return { result: 'ignored' };

    if (status === 'paid') {
      if (Number(amount) !== Number(p.amount)) return { result: 'amount_mismatch' }; // jangan percaya nominal dari luar
      await c.query(`UPDATE payments SET status='paid', paid_at=now() WHERE id=$1`, [p.id]);
      const up = await c.query(`UPDATE orders SET status='pembayaran_berhasil' WHERE id=$1 AND status='menunggu_pembayaran'`, [p.order_id]);
      if (!up.rowCount) {   // dibayar setelah pesanan dibatalkan -> perlu refund manual
        await c.query(`INSERT INTO transaction_logs(order_id,action,detail) VALUES ($1,'PAID_BUT_ORDER_NOT_PENDING_REFUND_MANUALLY',$2)`, [p.order_id, { gateway_ref: gatewayRef }]);
        return { result: 'paid_order_not_pending' };
      }
      await c.query(`INSERT INTO transaction_logs(order_id,action,from_status,to_status) VALUES ($1,'payment_confirmed','menunggu_pembayaran','pembayaran_berhasil')`, [p.order_id]);
      return { result: 'paid', orderId: p.order_id };
    }
    if (status === 'failed' || status === 'expired') {
      await c.query('UPDATE payments SET status=$2 WHERE id=$1', [p.id, status]);
      const cn = await c.query(`UPDATE orders SET status='dibatalkan' WHERE id=$1 AND status='menunggu_pembayaran' RETURNING voucher_id`, [p.order_id]);
      if (cn.rows[0]?.voucher_id) await c.query('UPDATE vouchers SET used_count=GREATEST(used_count-1,0) WHERE id=$1', [cn.rows[0].voucher_id]);
      return { result: status };
    }
    return { result: 'ignored' };
  });
}

// ===== Midtrans (Snap) =====
const MT = () => ({ key: process.env.MIDTRANS_SERVER_KEY,
  snap: process.env.MIDTRANS_ENV === 'production' ? 'https://app.midtrans.com/snap/v1/transactions' : 'https://app.sandbox.midtrans.com/snap/v1/transactions' });

export async function createMidtransSnap(orderNo, total, c) {
  const { key, snap } = MT();
  if (!key) throw new Error('MIDTRANS_SERVER_KEY belum diisi');
  const r = await fetch(snap, { method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: 'Basic ' + Buffer.from(key + ':').toString('base64') },
    body: JSON.stringify({ transaction_details: { order_id: orderNo, gross_amount: Math.round(Number(total)) },   // IDR: bilangan bulat
      customer_details: { email: c.email, phone: c.whatsapp }, expiry: { unit: 'minutes', duration: 60 } }) });
  const d = await r.json();
  if (!r.ok || !d.redirect_url) throw new Error('Midtrans: ' + JSON.stringify(d));
  return d;
}
// signature_key = SHA512(order_id + status_code + gross_amount + ServerKey)
export function verifyMidtrans(d) {
  const key = MT().key; if (!key || !d.signature_key) return false;
  const exp = crypto.createHash('sha512').update(String(d.order_id) + String(d.status_code) + String(d.gross_amount) + key).digest('hex');
  const a = Buffer.from(exp), b = Buffer.from(String(d.signature_key));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
