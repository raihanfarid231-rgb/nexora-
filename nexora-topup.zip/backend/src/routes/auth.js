import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import crypto from 'crypto';
import { q, tx } from '../db.js';
import { send } from '../mailer.js';
import { validate, requireAuth } from '../middleware.js';
const r = Router();
const strict = rateLimit({ windowMs: 15 * 60_000, limit: 10, message: { error: 'Terlalu banyak percobaan. Coba lagi nanti.' } });

const reg = z.object({
  username: z.string().trim().min(3).max(40).regex(/^[a-zA-Z0-9_]+$/),
  email: z.string().trim().email().max(120),
  password: z.string().min(8).max(100),
  confirm: z.string()
}).refine(d => d.password === d.confirm, { message: 'Konfirmasi password tidak sama', path: ['confirm'] });

r.post('/register', strict, validate(reg), async (req, res) => {
  const { username, email, password } = req.body;
  const hash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await q(
      `INSERT INTO users(role_id,username,email,password_hash) VALUES ((SELECT id FROM roles WHERE name='customer'),$1,$2,$3) RETURNING id`,
      [username, email, hash]);
    res.status(201).json({ id: rows[0].id });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Username atau email sudah dipakai.' });
    throw e;
  }
});

r.post('/login', strict, validate(z.object({ email: z.string().email(), password: z.string().min(1).max(100) })), async (req, res) => {
  const { rows } = await q(`SELECT u.id,u.username,u.password_hash,u.is_active,r.name AS role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.email=$1`, [req.body.email]);
  const u = rows[0];
  // Selalu jalankan compare agar waktu respons tidak membocorkan keberadaan akun
  const ok = await bcrypt.compare(req.body.password, u?.password_hash || '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
  if (!u || !ok || !u.is_active) return res.status(401).json({ error: 'Email atau password salah.' });
  req.session.regenerate(err => {
    if (err) throw err;
    req.session.user = { id: u.id, username: u.username, role: u.role };
    q('UPDATE users SET last_login_at=now() WHERE id=$1', [u.id]);
    res.json(req.session.user);
  });
});
r.post('/logout', (req, res) => req.session.destroy(() => { res.clearCookie('nx.sid'); res.json({ ok: true }); }));
r.get('/me', requireAuth, (req, res) => res.json(req.session.user));
r.get('/orders', requireAuth, async (req, res) => res.json((await q(
  `SELECT order_no,total,status,created_at FROM orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`, [req.session.user.id])).rows));

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
r.post('/forgot', strict, validate(z.object({ email: z.string().email() })), async (req, res) => {
  const u = (await q('SELECT id FROM users WHERE email=$1 AND is_active', [req.body.email])).rows[0];
  if (u) {
    const t = crypto.randomBytes(24).toString('hex');
    await q(`INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES ($1,$2,now()+interval '30 minutes')`, [u.id, sha(t)]);
    await send(req.body.email, 'Reset password NEXORA', `Buka tautan ini (berlaku 30 menit):\n${process.env.APP_URL || 'http://localhost:4000'}/auth.html#reset=${t}\nAbaikan jika bukan Anda.`);
  }
  res.json({ ok: true });                       // respons sama agar email tidak bisa ditebak
});
r.post('/reset', strict, validate(z.object({ token: z.string().length(48), password: z.string().min(8).max(100) })), async (req, res) => {
  const hash = await bcrypt.hash(req.body.password, 12);
  const ok = await tx(async c => {
    const pr = (await c.query('SELECT id,user_id FROM password_resets WHERE token_hash=$1 AND used_at IS NULL AND expires_at>now() FOR UPDATE', [sha(req.body.token)])).rows[0];
    if (!pr) return false;
    await c.query('UPDATE users SET password_hash=$2 WHERE id=$1', [pr.user_id, hash]);
    await c.query('UPDATE password_resets SET used_at=now() WHERE id=$1', [pr.id]);
    await c.query(`DELETE FROM session WHERE (sess->'user'->>'id')::bigint=$1`, [pr.user_id]);   // paksa logout semua perangkat
    return true;
  });
  if (!ok) return res.status(400).json({ error: 'Tautan tidak valid atau sudah kedaluwarsa.' });
  res.json({ ok: true });
});
export default r;
