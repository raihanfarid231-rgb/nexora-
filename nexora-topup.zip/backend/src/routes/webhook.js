import { Router } from 'express';
import { processPaymentEvent, verifySignature, verifyMidtrans } from '../payments.js';
import crypto from 'crypto';
import { fulfillOrder, applyProviderResult } from '../providers.js';
const r = Router();
// Format SANDBOX/umum. Saat memakai Midtrans/Xendit, ganti verifikasi dengan signature resmi mereka
// (Midtrans: SHA512(order_id+status_code+gross_amount+ServerKey); Xendit: header x-callback-token).
r.post('/payment', async (req, res) => {
  const raw = req.body;                                   // Buffer
  const valid = verifySignature(raw, req.get('X-Signature'));
  let d; try { d = JSON.parse(raw.toString('utf8')); } catch { return res.status(400).end(); }
  const rs = await processPaymentEvent({
    gateway: d.gateway || 'sandbox', eventId: String(d.event_id || ''), gatewayRef: String(d.ref || ''),
    status: d.status, amount: d.amount, payload: d, signatureValid: valid });
  if (!valid) return res.status(401).json({ error: 'Signature tidak valid.' });
  if (rs.result === 'paid') fulfillOrder(rs.orderId).catch(console.error);
  res.json({ ok: true, result: rs.result });              // 200 agar gateway tidak mengirim ulang tanpa henti
});

// Midtrans HTTP Notification URL: https://DOMAIN-ANDA/webhook/midtrans
r.post('/midtrans', async (req, res) => {
  let d; try { d = JSON.parse(req.body.toString('utf8')); } catch { return res.status(400).end(); }
  const valid = verifyMidtrans(d);
  const ts = d.transaction_status;
  const status = (ts === 'settlement' || (ts === 'capture' && d.fraud_status === 'accept')) ? 'paid'
    : ts === 'expire' ? 'expired' : ['deny', 'cancel', 'failure'].includes(ts) ? 'failed' : 'pending';
  const rs = await processPaymentEvent({ gateway: 'midtrans', eventId: `${d.transaction_id}-${ts}`, gatewayRef: String(d.order_id || ''),
    status, amount: parseFloat(d.gross_amount), payload: d, signatureValid: valid });
  if (!valid) return res.status(401).json({ error: 'Signature tidak valid.' });
  if (rs.result === 'paid') fulfillOrder(rs.orderId).catch(console.error);
  res.json({ ok: true, result: rs.result });
});

// Digiflazz callback: header X-Hub-Signature = 'sha1=' + HMAC-SHA1(body, secret webhook)
r.post('/digiflazz', async (req, res) => {
  const secret = process.env.DIGIFLAZZ_WEBHOOK_SECRET;
  const exp = Buffer.from('sha1=' + crypto.createHmac('sha1', secret || '').update(req.body).digest('hex'));
  const got = Buffer.from(req.get('X-Hub-Signature') || '');
  if (!secret || exp.length !== got.length || !crypto.timingSafeEqual(exp, got)) return res.status(401).end();
  let d; try { d = JSON.parse(req.body.toString('utf8')).data || {}; } catch { return res.status(400).end(); }
  await applyProviderResult(String(d.ref_id || ''), d.status, d.sn);
  res.json({ ok: true });
});
export default r;
