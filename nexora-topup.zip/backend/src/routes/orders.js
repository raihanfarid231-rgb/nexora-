import { Router } from 'express';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { q, tx } from '../db.js';
import { validate } from '../middleware.js';
import { processPaymentEvent, createMidtransSnap } from '../payments.js';
import { fulfillOrder } from '../providers.js';
const r = Router();
const limiter = rateLimit({ windowMs: 60_000, limit: 20 });
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const orderNo = () => 'NX' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + crypto.randomBytes(4).toString('hex').toUpperCase();

async function applyVoucher(c, code, price, consume) {
  const bad = m => Object.assign(new Error(m), { status: 400 });
  const v = (await c.query(`SELECT * FROM vouchers WHERE upper(code)=upper($1) AND is_active ${consume ? 'FOR UPDATE' : ''}`, [code])).rows[0];
  if (!v) throw bad('Kode voucher tidak valid.');
  const now = new Date();
  if ((v.starts_at && new Date(v.starts_at) > now) || (v.ends_at && new Date(v.ends_at) < now)) throw bad('Voucher sudah tidak berlaku.');
  if (v.quota != null && v.used_count >= v.quota) throw bad('Kuota voucher sudah habis.');
  if (price < Number(v.min_order)) throw bad('Belum memenuhi minimum pembelian voucher.');
  let d = v.type === 'percent' ? price * Number(v.value) / 100 : Number(v.value);
  if (v.max_discount != null) d = Math.min(d, Number(v.max_discount));
  d = Math.max(0, Math.min(Math.floor(d), price - 1000));            // total minimal Rp1.000
  if (consume) await c.query('UPDATE vouchers SET used_count=used_count+1 WHERE id=$1', [v.id]);
  return { id: v.id, discount: d };
}
const body = z.object({
  voucher: z.string().trim().max(40).optional(),
  productId: z.number().int().positive(),            // harga TIDAK diterima dari klien
  accountId: z.string().trim().min(3).max(50).regex(/^[\w.#-]+$/),
  zoneId: z.string().trim().max(20).regex(/^[\w-]*$/).optional(),
  method: z.string().trim().min(2).max(30),
  email: z.string().email().max(120).optional(),
  whatsapp: z.string().regex(/^\+?[0-9]{9,15}$/).optional()
}).refine(d => d.email || d.whatsapp, { message: 'Isi email atau WhatsApp', path: ['email'] });

r.post('/', limiter, validate(body), async (req, res) => {
  const b = req.body;
  const out = await tx(async c => {
    const p = (await c.query(
      `SELECT p.id,p.name,p.game_id,p.is_available,COALESCE(NULLIF(p.promo_price,NULL),p.price) AS base,
              p.promo_price,p.price,p.promo_ends_at,g.requires_zone_id
       FROM products p JOIN games g ON g.id=p.game_id WHERE p.id=$1 AND g.is_active`, [b.productId])).rows[0];
    if (!p || !p.is_available) throw Object.assign(new Error('Produk tidak tersedia.'), { status: 400 });
    if (p.requires_zone_id && !b.zoneId) throw Object.assign(new Error('Zone/Server ID wajib diisi.'), { status: 400 });
    const promoOn = p.promo_price != null && (!p.promo_ends_at || new Date(p.promo_ends_at) > new Date());
    const price = Number(promoOn ? p.promo_price : p.price);
    const fee = 0; let discount = 0, voucherId = null;
    if (b.voucher) { const v = await applyVoucher(c, b.voucher, price, true); discount = v.discount; voucherId = v.id; }
    const total = price + fee - discount;                              // dihitung server
    const no = orderNo(), token = crypto.randomBytes(16).toString('hex');
    const o = (await c.query(
      `INSERT INTO orders(order_no,user_id,contact_email,contact_whatsapp,subtotal,fee,discount,total,lookup_token_hash,voucher_id,expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now()+interval '60 minutes') RETURNING id`,
      [no, req.session.user?.id || null, b.email || null, b.whatsapp || null, price, fee, discount, total, sha(token), voucherId])).rows[0];
    await c.query(
      `INSERT INTO order_items(order_id,product_id,game_id,account_id,zone_id,product_name,unit_price) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [o.id, p.id, p.game_id, b.accountId, b.zoneId || null, p.name, price]);
    const gwRef = (process.env.PAYMENT_GATEWAY || 'sandbox') === 'midtrans' ? no : 'SBX-' + no;  // Midtrans order_id = nomor pesanan
    await c.query(`INSERT INTO payments(order_id,gateway,method,gateway_ref,amount,expires_at) VALUES ($1,$2,$3,$4,$5, now()+interval '60 minutes')`,
      [o.id, process.env.PAYMENT_GATEWAY || 'sandbox', b.method, gwRef, total]);
    await c.query(`INSERT INTO transaction_logs(order_id,action,to_status) VALUES ($1,'order_created','menunggu_pembayaran')`, [o.id]);
    return { orderNo: no, lookupToken: token, total, paymentMode: process.env.PAYMENT_GATEWAY || 'sandbox' };
  });
  if (out.paymentMode === 'midtrans') {
    try {
      const s = await createMidtransSnap(out.orderNo, out.total, b);
      await q('UPDATE payments SET pay_url=$2 WHERE gateway_ref=$1', [out.orderNo, s.redirect_url]);
    } catch (e) {
      console.error(e);
      await q(`UPDATE vouchers SET used_count=GREATEST(used_count-1,0) WHERE id=(SELECT voucher_id FROM orders WHERE order_no=$1)`, [out.orderNo]);
      await q(`UPDATE orders SET status='dibatalkan' WHERE order_no=$1`, [out.orderNo]);
      return res.status(502).json({ error: 'Gagal membuat pembayaran. Coba lagi.' });
    }
  }
  res.status(201).json(out);   // lookupToken hanya ditampilkan sekali
});

r.post('/voucher-check', limiter, validate(z.object({ code: z.string().trim().min(1).max(40), productId: z.number().int().positive() })), async (req, res) => {
  const p = (await q(`SELECT price,promo_price,promo_ends_at FROM products WHERE id=$1 AND is_available`, [req.body.productId])).rows[0];
  if (!p) return res.status(400).json({ error: 'Produk tidak tersedia.' });
  const on = p.promo_price != null && (!p.promo_ends_at || new Date(p.promo_ends_at) > new Date());
  const v = await applyVoucher({ query: q }, req.body.code, Number(on ? p.promo_price : p.price), false);
  res.json({ discount: v.discount });
});
r.post('/testimonial', limiter, validate(z.object({ orderNo: z.string().max(30), token: z.string().max(64), displayName: z.string().trim().min(2).max(60), content: z.string().trim().min(10).max(500) })), async (req, res) => {
  const o = (await q(`SELECT id,lookup_token_hash,status FROM orders WHERE order_no=$1`, [req.body.orderNo])).rows[0];
  if (!o || sha(req.body.token) !== o.lookup_token_hash || o.status !== 'berhasil') return res.status(404).json({ error: 'Pesanan tidak ditemukan atau belum selesai.' });
  await q(`INSERT INTO testimonials(order_id,display_name,content) VALUES ($1,$2,$3) ON CONFLICT (order_id) DO NOTHING`, [o.id, req.body.displayName, req.body.content]);
  res.status(201).json({ ok: true });          // tampil setelah disetujui admin
});

// Cek pesanan: butuh nomor pesanan + token (atau pemilik akun yang login)
r.get('/:no', limiter, async (req, res) => {
  const o = (await q(`SELECT o.id,o.order_no,o.status,o.total,o.created_at,o.user_id,o.lookup_token_hash,
      (SELECT json_agg(json_build_object('product',product_name,'accountId',account_id,'zoneId',zone_id,'status',fulfillment_status)) FROM order_items WHERE order_id=o.id) AS items,
      (SELECT pay_url FROM payments WHERE order_id=o.id ORDER BY id DESC LIMIT 1) AS pay_url
      FROM orders o WHERE order_no=$1`, [req.params.no])).rows[0];
  const t = req.query.token ? sha(String(req.query.token)) : null;
  const allowed = o && ((t && t === o.lookup_token_hash) || (req.session.user && req.session.user.id === o.user_id));
  if (!allowed) return res.status(404).json({ error: 'Pesanan tidak ditemukan.' });  // pesan sama agar nomor tidak bisa ditebak
  const { id, user_id, lookup_token_hash, ...pub } = o;
  res.json(pub);
});

// SIMULASI pembayaran — hanya aktif saat PAYMENT_GATEWAY=sandbox. Melewati jalur validasi yang sama dengan webhook.
r.post('/:no/sandbox-pay', limiter, async (req, res) => {
  if ((process.env.PAYMENT_GATEWAY || 'sandbox') !== 'sandbox') return res.status(404).json({ error: 'Tidak tersedia.' });
  const row = (await q(`SELECT p.gateway_ref,p.amount,o.id,o.lookup_token_hash FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.order_no=$1`, [req.params.no])).rows[0];
  if (!row || sha(String(req.body?.token || '')) !== row.lookup_token_hash) return res.status(404).json({ error: 'Pesanan tidak ditemukan.' });
  const payload = JSON.stringify({ ref: row.gateway_ref, status: 'paid', amount: row.amount, simulated: true });
  const rs = await processPaymentEvent({ gateway: 'sandbox', eventId: 'sim-' + row.gateway_ref, gatewayRef: row.gateway_ref, status: 'paid', amount: row.amount, payload: JSON.parse(payload), signatureValid: true });
  if (rs.result === 'paid') fulfillOrder(rs.orderId).catch(console.error);
  res.json({ simulated: true, result: rs.result });
});
export default r;
