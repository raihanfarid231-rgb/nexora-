import { Router } from 'express';
import { q } from '../db.js';
const r = Router();
r.get('/categories', async (_, res) => res.json((await q('SELECT id,name,slug FROM game_categories WHERE is_active ORDER BY sort_order')).rows));
r.get('/games', async (req, res) => {
  const { category, search } = req.query;
  const { rows } = await q(
    `SELECT g.id,g.name,g.slug,g.publisher,g.image_url,g.label,c.name AS category,
            (SELECT MIN(COALESCE(promo_price,price)) FROM products p WHERE p.game_id=g.id AND p.is_available) AS price_from
     FROM games g JOIN game_categories c ON c.id=g.category_id
     WHERE g.is_active AND ($1::text IS NULL OR c.slug=$1) AND ($2::text IS NULL OR g.name ILIKE '%'||$2||'%')
     ORDER BY g.sort_order`, [category || null, search ? String(search).slice(0, 50) : null]);
  res.json(rows);
});
r.get('/games/:slug', async (req, res) => {
  const g = (await q('SELECT id,name,slug,publisher,currency_name,requires_zone_id,id_help_text FROM games WHERE slug=$1 AND is_active', [req.params.slug])).rows[0];
  if (!g) return res.status(404).json({ error: 'Game tidak ditemukan.' });
  const products = (await q(
    `SELECT id,name,description,price,promo_price,promo_label,is_available FROM products
     WHERE game_id=$1 ORDER BY sort_order`, [g.id])).rows;
  res.json({ ...g, products });
});
r.get('/banners', async (_, res) => res.json((await q(
  `SELECT id,title,subtitle,image_url,link_url,ends_at FROM banners
   WHERE is_active AND (starts_at IS NULL OR starts_at<=now()) AND (ends_at IS NULL OR ends_at>=now()) ORDER BY sort_order`)).rows));
r.get('/articles', async (_, res) => res.json((await q(
  `SELECT id,title,slug,excerpt,image_url,published_at FROM articles WHERE is_published ORDER BY published_at DESC LIMIT 12`)).rows));
r.get('/articles/:slug', async (req, res) => {
  const a = (await q(`SELECT title,body,image_url,published_at FROM articles WHERE slug=$1 AND is_published`, [req.params.slug])).rows[0];
  a ? res.json(a) : res.status(404).json({ error: 'Artikel tidak ditemukan.' });
});
r.get('/testimonials', async (_, res) => res.json((await q(`SELECT display_name,content FROM testimonials WHERE is_approved ORDER BY created_at DESC LIMIT 12`)).rows));
r.get('/settings', async (_, res) => {
  const { rows } = await q(`SELECT key,value FROM settings WHERE key IN ('site_name','whatsapp_number','whatsapp_enabled','contact_email')`);
  res.json(Object.fromEntries(rows.map(x => [x.key, x.value])));
});
export default r;
