import { Router } from 'express';
import { z } from 'zod';
import { q } from '../db.js';
import { requireRole, validate } from '../middleware.js';
import { fulfillOrder } from '../providers.js';
const r = Router();
r.use(requireRole('admin', 'superadmin'));            // SEMUA endpoint admin dijaga di server

r.get('/stats', async (_, res) => {
  const s = (await q(`SELECT
    (SELECT count(*) FROM orders) AS total_orders,
    (SELECT COALESCE(sum(total),0) FROM orders WHERE status IN ('pembayaran_berhasil','sedang_diproses','berhasil')) AS revenue_verified,
    (SELECT count(*) FROM orders WHERE status='menunggu_pembayaran') AS pending,
    (SELECT count(*) FROM orders WHERE status='berhasil') AS success,
    (SELECT count(*) FROM users) AS users`)).rows[0];
  const daily = (await q(`SELECT date_trunc('day',created_at)::date AS day, count(*) AS orders, COALESCE(sum(total),0) AS revenue
    FROM orders WHERE status IN ('pembayaran_berhasil','sedang_diproses','berhasil') AND created_at>now()-interval '30 days' GROUP BY 1 ORDER BY 1`)).rows;
  const top = (await q(`SELECT product_name, sum(quantity) AS sold FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='berhasil' GROUP BY 1 ORDER BY 2 DESC LIMIT 5`)).rows;
  const recent = (await q(`SELECT order_no,total,status,created_at FROM orders ORDER BY created_at DESC LIMIT 10`)).rows;
  res.json({ ...s, daily, top, recent });
});
r.get('/orders', async (_, res) => res.json((await q(`SELECT order_no,total,status,created_at FROM orders ORDER BY created_at DESC LIMIT 100`)).rows));

const prod = z.object({
  gameId: z.number().int().positive(), name: z.string().min(1).max(100), sku: z.string().min(1).max(60),
  costPrice: z.number().nonnegative(), price: z.number().nonnegative(),
  isAvailable: z.boolean().default(true)
});
r.post('/products', validate(prod), async (req, res) => {
  const b = req.body;
  const { rows } = await q(`INSERT INTO products(game_id,name,sku,cost_price,price,is_available) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
    [b.gameId, b.name, b.sku, b.costPrice, b.price, b.isAvailable]);
  res.status(201).json(rows[0]);
});
const patch = z.object({ name: z.string().min(1).max(100).optional(), price: z.number().nonnegative().optional(),
  costPrice: z.number().nonnegative().optional(), isAvailable: z.boolean().optional() });
r.get('/products', async (_, res) => res.json((await q(
  `SELECT p.id,p.game_id,g.name AS game,p.name,p.sku,p.cost_price,p.price,p.is_available FROM products p JOIN games g ON g.id=p.game_id ORDER BY g.sort_order,p.sort_order`)).rows));
r.patch('/products/:id', validate(patch), async (req, res) => {
  const b = req.body;
  await q(`UPDATE products SET name=COALESCE($2,name), price=COALESCE($3,price), cost_price=COALESCE($4,cost_price), is_available=COALESCE($5,is_available) WHERE id=$1`,
    [req.params.id, b.name, b.price, b.costPrice, b.isAvailable]);
  res.json({ ok: true });
});
r.delete('/products/:id', async (req, res) => {
  try { await q('DELETE FROM products WHERE id=$1', [req.params.id]); res.json({ ok: true }); }
  catch (e) { if (e.code === '23503') return res.status(409).json({ error: 'Produk sudah dipakai pesanan. Nonaktifkan saja.' }); throw e; }
});

// ===== CRUD generik (kolom di-whitelist; tipe divalidasi zod) =====
// '!' = wajib. Tipe: str,text,slug,url,int,num,bool,date,enum:a,b
const RES = {
  categories: { t: 'game_categories', c: { name: 'str!', slug: 'slug!', sort_order: 'int', is_active: 'bool' } },
  games: { t: 'games', c: { category_id: 'int!', name: 'str!', slug: 'slug!', publisher: 'str', image_url: 'url', requires_zone_id: 'bool', id_help_text: 'text', label: 'enum:HOT,POPULER', is_active: 'bool', sort_order: 'int' } },
  banners: { t: 'banners', c: { title: 'str!', subtitle: 'str', image_url: 'url', link_url: 'url', starts_at: 'date', ends_at: 'date', sort_order: 'int', is_active: 'bool' } },
  articles: { t: 'articles', c: { title: 'str!', slug: 'slug!', excerpt: 'text', body: 'text!', image_url: 'url', is_published: 'bool' } },
  vouchers: { t: 'vouchers', c: { code: 'str!', type: 'enum:percent,fixed!', value: 'num!', max_discount: 'num', min_order: 'num', quota: 'int', starts_at: 'date', ends_at: 'date', is_active: 'bool' } },
  testimonials: { t: 'testimonials', c: { display_name: 'str!', content: 'text!', is_approved: 'bool' } }
};
function zf(spec) {
  const req = spec.endsWith('!'), t = spec.replace(/!$/, ''); let s;
  if (t === 'int') s = z.number().int(); else if (t === 'num') s = z.number().nonnegative(); else if (t === 'bool') s = z.boolean();
  else if (t === 'date') s = z.string().datetime({ offset: true });
  else if (t === 'slug') s = z.string().regex(/^[a-z0-9-]{1,100}$/, 'Slug: huruf kecil, angka, tanda minus');
  else if (t === 'url') s = z.string().max(500).regex(/^(https?:\/\/|\/)/, 'URL harus diawali http(s):// atau /');
  else if (t.startsWith('enum:')) s = z.enum(t.slice(5).split(','));
  else s = z.string().trim().min(req ? 1 : 0).max(t === 'text' ? 20000 : 200);
  return req ? s : s.nullable().optional();
}
for (const R of Object.values(RES)) { R.keys = Object.keys(R.c); R.zc = z.object(Object.fromEntries(R.keys.map(k => [k, zf(R.c[k])]))); R.zp = R.zc.partial(); }
const dbErr = (e, res) => {
  if (e.code === '23505') return res.status(409).json({ error: 'Data duplikat (slug/kode sudah dipakai).' });
  if (e.code === '23503') return res.status(409).json({ error: 'Data masih terhubung ke data lain atau ID rujukan tidak ada.' });
  if (['22P02', '23514', '23502'].includes(e.code)) return res.status(400).json({ error: 'Isi data tidak valid.' });
  throw e;
};
const R_ = (req, res, next) => { req.R = RES[req.params.res]; req.R ? next() : res.status(404).json({ error: 'Tidak ditemukan.' }); };
const after = async (name, id, req) => {
  if (name === 'articles') await q('UPDATE articles SET published_at=COALESCE(published_at,now()), author_id=COALESCE(author_id,$2) WHERE id=$1 AND is_published', [id, req.session.user.id]);
};
r.get('/schema', (_, res) => res.json(Object.fromEntries(Object.entries(RES).map(([k, v]) => [k, v.c]))));
r.get('/r/:res', R_, async (req, res) => res.json((await q(`SELECT * FROM ${req.R.t} ORDER BY id DESC LIMIT 200`)).rows));
r.post('/r/:res', R_, (req, res, next) => validate(req.R.zc)(req, res, next), async (req, res) => {
  const k = Object.keys(req.body);
  try {
    const { rows } = await q(`INSERT INTO ${req.R.t}(${k.join(',')}) VALUES (${k.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING id`, k.map(x => req.body[x]));
    await after(req.params.res, rows[0].id, req); res.status(201).json(rows[0]);
  } catch (e) { dbErr(e, res); }
});
r.patch('/r/:res/:id', R_, (req, res, next) => validate(req.R.zp)(req, res, next), async (req, res) => {
  const k = Object.keys(req.body); if (!k.length) return res.json({ ok: true });
  try {
    await q(`UPDATE ${req.R.t} SET ${k.map((x, i) => `${x}=$${i + 2}`).join(',')} WHERE id=$1`, [req.params.id, ...k.map(x => req.body[x])]);
    await after(req.params.res, req.params.id, req); res.json({ ok: true });
  } catch (e) { dbErr(e, res); }
});
r.delete('/r/:res/:id', R_, async (req, res) => {
  try { await q(`DELETE FROM ${req.R.t} WHERE id=$1`, [req.params.id]); res.json({ ok: true }); } catch (e) { dbErr(e, res); }
});

// Pengaturan situs (WhatsApp mengambang dll.)
const empty = v => v === '' ? undefined : v;
r.get('/settings', async (_, res) => res.json(Object.fromEntries((await q('SELECT key,value FROM settings')).rows.map(x => [x.key, x.value]))));
r.put('/settings', validate(z.object({
  site_name: z.string().trim().max(60).optional(), whatsapp_number: z.string().regex(/^[0-9]{9,15}$|^$/).optional(),
  whatsapp_enabled: z.enum(['true', 'false']).optional(), contact_email: z.string().email().or(z.literal('')).optional() })), async (req, res) => {
  for (const [k, v] of Object.entries(req.body)) await q(`INSERT INTO settings(key,value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=$2`, [k, v]);
  res.json({ ok: true });
});
// Coba ulang pengiriman ke distributor (ref_id sama = tidak terkirim ganda)
r.post('/orders/:no/retry', async (req, res) => {
  const o = (await q('SELECT id FROM orders WHERE order_no=$1', [req.params.no])).rows[0];
  if (!o) return res.status(404).json({ error: 'Pesanan tidak ditemukan.' });
  await fulfillOrder(o.id); res.json({ ok: true });
});
export default r;
