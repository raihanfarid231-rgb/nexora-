import nodemailer from 'nodemailer';
let t;
export async function send(to, subject, text) {
  if (!to) return;
  if (!process.env.SMTP_HOST) { console.log(`[EMAIL-DEV, SMTP belum diatur] to=${to} | ${subject}\n${text}`); return; }
  t ??= nodemailer.createTransport({ host: process.env.SMTP_HOST, port: +(process.env.SMTP_PORT || 587), secure: process.env.SMTP_PORT === '465',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
  await t.sendMail({ from: process.env.MAIL_FROM, to, subject, text }).catch(e => console.error('Email gagal:', e.message));
}
