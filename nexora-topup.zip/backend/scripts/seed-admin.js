// LOKAL SAJA. Contoh: ADMIN_EMAIL=admin@local.test ADMIN_PASSWORD='password-kuat-anda' npm run seed:admin
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { q, pool } from '../src/db.js';
const { ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
if (!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12) { console.error('Isi ADMIN_EMAIL dan ADMIN_PASSWORD (min. 12 karakter).'); process.exit(1); }
await q(`INSERT INTO users(role_id,username,email,password_hash) VALUES ((SELECT id FROM roles WHERE name='superadmin'),'admin',$1,$2)
         ON CONFLICT (email) DO NOTHING`, [ADMIN_EMAIL, await bcrypt.hash(ADMIN_PASSWORD, 12)]);
console.log('Admin dibuat. Ganti password sebelum deploy.'); await pool.end();
